import { DatabaseManager } from "../repository";
import { TicketCategory, TicketStatus, User, TicketComment } from "../types";
import { Ticket } from "./Ticket";
import { TicketFactory } from "./TicketFactory";
import { ERROR_MESSAGES } from "../constante.error";
import { postTicketComment } from "./ticket-command";
import { addTicketUsers } from "./ticket-details";


export class TicketService {
    static getTickets(status?: TicketStatus, category?: TicketCategory, search?: string) {
        const database = DatabaseManager.getInstance().readDatabase();
        let tickets = database.tickets;

        tickets = this.filterTickets(tickets, status, category, search);
        const ticketsWithUsers = tickets.map((ticket) => addTicketUsers(ticket, database.users));

        return ticketsWithUsers.map((tickets) => ({
            ...tickets,
            commentsCount: database.comments.filter(
                (comment) => comment.ticketId === tickets.id
            ).length,
        }));
    }

    private static filterTickets(tickets: Ticket[], status?: TicketStatus, category?: TicketCategory, search?: string) {
        if (status) {
            tickets = tickets.filter((ticket) => ticket.status === status);
        }

        if (category) {
            tickets = tickets.filter((ticket) => ticket.category === category);
        }

        if (search) {
            const ticketSearch = String(search).toLowerCase();
            tickets = tickets.filter(
                (ticket) =>
                    ticket.title.toLowerCase().includes(ticketSearch) ||
                    ticket.description.toLowerCase().includes(ticketSearch) ||
                    ticket.category.toLowerCase().includes(ticketSearch),
            );
        }

        return tickets;
    }

    static getSummary() {
        const database = DatabaseManager.getInstance().readDatabase();
        const summary = {
            open: 0,
            in_progress: 0,
            resolved: 0,
            closed: 0,
            urgent: 0,
        };

        for (const ticket of database.tickets) {
            if (ticket.status === "open") summary.open++;
            if (ticket.status === "in_progress") summary.in_progress++;
            if (ticket.status === "resolved") summary.resolved++;
            if (ticket.status === "closed") summary.closed++;
            if (ticket.priority === "urgent") summary.urgent++;
        }

        return summary;
    }

    static getTicketById(ticketId: string) {
        const database = DatabaseManager.getInstance().readDatabase();
        const ticket = database.tickets.find((item) => item.id === ticketId);

        if (!ticket) {
            return null;
        }


        const ticketsWithUsers = addTicketUsers(ticket, database.users);
        const comments = database.comments
            .filter((comment) => comment.ticketId === ticket.id)
            .map((comment) => ({
                ...comment,
                author: database.users.find((user) => user.id === comment.authorId),
            }));

        return {
            ...ticketsWithUsers,
            comments,
        };
    }

    static getUser(userId: string) {
        const database = DatabaseManager.getInstance().readDatabase();
        const user = database.users.find((item) => item.id === userId);

        return user || null;
    }



    static patchTicketStatus(ticketId: string, newStatus: TicketStatus, comment?: string, authorId?: string) {
        const database = DatabaseManager.getInstance().readDatabase();
        const ticket = database.tickets.find((item) => item.id === ticketId);

        if (!ticket) {
            return { success: false, error: ERROR_MESSAGES.TICKET_NOT_FOUND };
        }

        ticket.status = newStatus;
        ticket.updatedAt = new Date().toISOString();

        if (comment) {
            database.comments.push({
                id: DatabaseManager.generateId("comment"),
                ticketId: ticket.id,
                authorId: authorId || ticket.requesterId,
                message: comment,
                createdAt: new Date().toISOString(),
            });
        }

        DatabaseManager.getInstance().writeDatabase(database);
        return { success: true, ticket };
    }

}